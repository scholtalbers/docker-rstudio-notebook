#' gx_set_env
#'
#' Function that wraps the setenv calls to set the appropriate Galaxy environment variables
#'
#' @param API_KEY, to access your Galaxy account
#' @param GALAXY_URL, default 'http://usegalaxy.org'
#' @param HISTORY_ID, the Galaxy history id to work on
#' @param IMPORT_DIRECTORY, default '/tmp/<username>/galaxy_import'
#' @param TMP_DIRECTORY, default '/tmp/<username>/galaxy_import/tmp'

gx_set_env <- function(API_KEY, GALAXY_URL='http://usegalaxy.org',
                        HISTORY_ID=NULL, IMPORT_DIRECTORY=NULL, TMP_DIRECTORY=NULL){
    Sys.setenv('GX_API_KEY'=API_KEY)
    if(is.null(HISTORY_ID)){
        message("You have not specified a history id, run gx_list_histories to see which are available")
        HISTORY_ID=''
    }
    Sys.setenv('GX_HISTORY_ID'=HISTORY_ID)
    Sys.setenv('GX_URL'=GALAXY_URL)
    username <- Sys.getenv('RSTUDIO_USER_IDENTITY')
    if(is.null(IMPORT_DIRECTORY)){
        IMPORT_DIRECTORY=file.path("/tmp",username,"galaxy_import")
    }
    Sys.setenv('GX_IMPORT_DIRECTORY'=IMPORT_DIRECTORY)

    if(is.null(TMP_DIRECTORY)){
        TMP_DIRECTORY=file.path(IMPORT_DIRECTORY,"tmp")
    }
    Sys.setenv('GX_TMP_DIRECTORY'=TMP_DIRECTORY)
}


#' directory_exists
#'
#' Return directory name if exists. If create is TRUE, creates directory, else stop
#'
#' @param directory, the directory to check
#' @param create, directory if true

directory_exists <- function(directory,create='FALSE'){
    # ensure directory exists
    if (!dir.exists(directory)){
        if(create){
            dir.create(directory,recursive=TRUE)
        }else{
            stop(paste(directory, 'does not exist. You can specify '))
        }
    }else{
        return(directory)
    }
}

#' gx_get_import_directory
#'
#' This function returns the import directory to work with
#'
#' @param create, if TRUE, create import directory if it does not exist

gx_get_import_directory <- function(create=FALSE){
    import_directory <- Sys.getenv('GX_IMPORT_DIRECTORY')
    history = Sys.getenv('GX_HISTORY_ID')
    history_import_directory = file.path(import_directory, history)
    return(directory_exists(history_import_directory,create=create))
}


#' gx_get_tmp_directory
#'
#' This function returns the tmp directory to work with
#'
#' @param create, if TRUE, create import directory if it does not exist

gx_get_tmp_directory <- function(create=FALSE){
    tmp_directory <- Sys.getenv('GX_TMP_DIRECTORY')
    return(directory_exists(tmp_directory,create=create))
}

#' gx_put
#'
#' This function uploads a dataset to the current Galaxy history
#'
#' @param filename, Path to file
#' @param file_type, auto-detect otherwise

gx_put <- function(filename, file_type="auto"){
    command <- paste(
        Sys.getenv('GX_PYTHON_BIN'), Sys.getenv('GX_PYTHON_FILE'),
        "--action", "put", "--argument", filename, "--filetype", file_type)
    system(command)
}

#' gx_get
#'
#' Download a dataset from the current Galaxy history by ID #
#'
#' @param file_id, ID number
#' @param create, if TRUE, create import directory if it does not exist

gx_get <- function(file_id,create=FALSE){
    history_import_directory = file.path(gx_get_import_directory(create=create))
    file_path = file.path(history_import_directory, file_id)
    command <- paste(
        Sys.getenv('GX_PYTHON_BIN'), Sys.getenv('GX_PYTHON_FILE'),
        "--action", "get", "--argument", file_id, "--file-path", file_path)
    system(command)
    return(file_path)
}


#' gx_save
#'
#' Save the notebook .RData and .RHistory to Galaxy. Convenience function which wraps save.image and gx_put
#'
#' @param session_name, default "workspace"

gx_save <- function(session_name="workspace"){
    workspace <- paste(gx_get_tmp_directory(),session_name,".RData",sep="")
    hist <- paste(gx_get_tmp_directory(),session_name,".RHistory",sep="")
    save.image(workspace)
    savehistory(hist)
    gx_put(workspace)
    gx_put(hist)
}


#' gx_restore
#'
#' Restore the notebook from a .RData and .RHistory object from the current Galaxy history.
#'
#' @param rdata_id, .RData ID number
#' @param rhistory_id, .RHistory ID number

gx_restore <- function(rdata_id,rhistory_id){
    rdata <- gx_get(rdata_id)
    rhistory <- gx_get(rhistory_id)
    load(rdata,envir=.GlobalEnv)
    loadhistory(rhistory)
}


#' gx_switch_history
#'
#' Convenience method to set the current history id in the environment setting
#'
#' @param HISTORY_ID, the Galaxy history id to work on

gx_switch_history <- function(HISTORY_ID){
    Sys.setenv('GX_HISTORY_ID'=HISTORY_ID)
}


#' gx_list_histories
#'
#' List all Galaxy histories of the current user

gx_list_histories <- function(){
    command <- paste(
        Sys.getenv('GX_PYTHON_BIN'), Sys.getenv('GX_PYTHON_FILE'),
        "--action", "histories")
    system(command)
}
